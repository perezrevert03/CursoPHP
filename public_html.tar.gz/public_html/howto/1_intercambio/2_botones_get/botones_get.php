<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
// Recogida de valores				 
echo("<br><h3>Ejemplo de botones en formularios GET</h3>");
$boton_G = $_GET['boton_G'];
echo("<br>boton_G: $boton_G");
$boton_H = $_GET['boton_H'];
echo("<br>boton_H: $boton_H");
$boton_I = $_GET['boton_I'];
echo("<br>boton_I: $boton_I");
$boton_J = $_GET['boton_J'];
echo("<br>boton_J: $boton_J");
$boton_K = $_GET['boton_K'];
echo("<br>boton_K: $boton_K");
$boton_L = $_GET['boton_L'];
echo("<br>boton_L: $boton_L");
?>