<?php setcookie("valor_D","Uno");?>
<html>
<head></head>
<body>
<h3>Ejemplo de cookies</h3>
<a href="cookies_s.php">Enlace</a>
<hr>
</body>
</html>
