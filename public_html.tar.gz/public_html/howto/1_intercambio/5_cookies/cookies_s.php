<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
echo("<br><h3>Ejemplo de cookies</h3>");
$valor_D=$_COOKIE['valor_D']/* A Rellenar */;
echo("<br>valor_D: $valor_D");
?>