<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
echo("<h3>Ejemplo de botones en formularios (POST)</h3>");
// Recogida de valores				 
echo("<br><h3>Ejemplo de botones en formularios POST</h3>");
$boton_A = $_POST['boton_A'];
echo("<br>boton_A: $boton_A");
$boton_B = $_POST['boton_B'];
echo("<br>boton_B: $boton_B");
$boton_C = $_POST['boton_C'];
echo("<br>boton_C: $boton_C");
$boton_D = $_POST['boton_D'];
echo("<br>boton_D: $boton_D");
$boton_E = $_POST['boton_E'];
echo("<br>boton_E: $boton_E");
$boton_F = $_POST['boton_F'];
echo("<br>boton_F: $boton_F");
?>