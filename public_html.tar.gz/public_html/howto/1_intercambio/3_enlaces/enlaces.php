<?php
// Desactivaci�n de errores
error_reporting(0);
// Recogida de valores				 
echo("<br><h3>Ejemplo de enlaces (GET)</h3>");
$valor_A = $_GET['valor_A'];
echo("<br>valor_A: $valor_A");
$valor_B = $_GET['valor_B'];;
echo("<br>valor_B: $valor_B");
?>