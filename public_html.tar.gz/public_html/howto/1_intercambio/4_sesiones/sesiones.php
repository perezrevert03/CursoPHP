<?php session_start();?>
<html>
<head></head>
<body>
<h3>Ejemplo de sesiones</h3>
<?php $_SESSION['valor_C']="Uno";?>
<a href="sesiones_s.php">Enlace</a>
<hr>
</body>
</html>
