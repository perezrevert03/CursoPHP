<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
// Recogida de valores				 
echo("<br><h3>Ejemplo de controles de texto</h3>");
$valor_text = $_POST['valor_text'];
echo("<br>valor_text: $valor_text");
$valor_password = $_POST['valor_password'];
echo("<br>valor_password: $valor_password");
$valor_area = $_POST['valor_area'];
echo("<br>valor_area: $valor_area");
?>
