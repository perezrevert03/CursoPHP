<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
// Recogida de valores				 
echo("<br><h3>Ejemplo de Radio buttons</h3>");
$valor_rb = $_POST['valor_rb'];
echo("<br>valor_rb: $valor_rb");
$valor_rb_sel = $_POST['valor_rb_sel'];
echo("<br>valor_rb_sel: $valor_rb_sel");
$valor_rb_val = $_POST['valor_rb_val'];
echo("<br>valor_rb_val: $valor_rb_val");
$valor_varios_rb = $_POST['valor_varios_rb'];
echo("<br>valor_varios_rb: $valor_varios_rb");
?>