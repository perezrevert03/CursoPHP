<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
// Recogida de valores				 
$valor_archivo= $_POST['valor_archivo'];
echo("<br>valor_archivo: $valor_archivo");
$valor_oculto= $_POST['valor_oculto'];
echo("<br>valor_oculto: $valor_oculto");
$valor_imagen= $_POST['valor_imagen'];
echo("<br>valor_imagen: $valor_imagen");
?>