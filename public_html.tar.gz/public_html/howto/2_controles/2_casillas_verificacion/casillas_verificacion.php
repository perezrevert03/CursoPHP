<?php
// Desactivar toda notificaci�n de error
error_reporting(0);
// Recogida de valores				 
echo("<br><h3>Ejemplo de casillas de verificacion</h3>");
$valor_cb = $_POST['valor_cb'];
echo("<br>valor_cb: $valor_cb");
$valor_cb_sel = $_POST['valor_cb_sel'];
echo("<br>valor_cb_sel: $valor_cb_sel");
$valor_cb_value = $_POST['valor_cb_value'];
echo("<br>valor_cb_value: $valor_cb_value");
?>