<html><head>
  <title>Tienda de recambios de Bob - Resultados</title>
</head>
<body>
<h1>Tienda de recambios de Bob</h1>
<h2>Resultados</h2>
<?php
  echo "<p>Petici�n procesada.</p>";
?>
</body>
</html>
