<tr>
    <td nowrap='nowrap'><?php echo "$titulo ($precio &euro;/ud)" ?></td>
    <td align="center">
        <input type="text" name="num<?= $nombre ?>" size="3" maxlength="3">
    </td>
</tr>

<?php
// Imprime una línea de la tabla del formulario
// Los parámetros de entrada deben ser: $titulo, $nombre y $precio

?>

