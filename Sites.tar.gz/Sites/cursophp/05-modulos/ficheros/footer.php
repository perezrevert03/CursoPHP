        </td>
      </tr>
      <tr>
        <td class="footer">
           <center>
              <address>
                 <small>Tienda de Recambios de BOB.</small>
                 <small>Hora: <?php echo date("H:i:s"); ?></small>
                 <small>Fecha: <?php echo date("j/m/Y"); ?></small>
                 <br>
                 <small>Webmaster: <a href="mailto:bob@nowhere.com">bob@nowhere.com</a></small>
              </address>
           </center>
        </td>
      </tr>
    </table>
   </body>
</html>
