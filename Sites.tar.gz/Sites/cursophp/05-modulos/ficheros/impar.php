<h2>La hora tiene los segundos impares</h2>

Compruebalo:

<?php
echo date("H:i:s");
?>
