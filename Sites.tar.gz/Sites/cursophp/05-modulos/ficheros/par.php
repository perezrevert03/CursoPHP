<h2>La hora tiene los segundos pares</h2>

Compruebalo:

<?php
echo date("H:i:s");
?>
