<?php

// Estructuras de datos comunes
$productos= array("frenos" => array("desc"=>"Frenos",
    "precio"=>100),
    "aceite" => array("desc"=>"Latas de aceite",
        "precio"=>10),
    "ruedas" => array("desc"=>"Neumáticos",
        "precio"=>4),
    "bujias" => array("desc"=>"Bujías",
        "precio"=>2)
);
?>
