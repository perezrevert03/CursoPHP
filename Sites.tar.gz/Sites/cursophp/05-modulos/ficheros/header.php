<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
   <head>
      <title>Tienda de recambios de Bob</title>
      <meta name="AUTHOR" content="Sergio S�ez" />
      <style>
    body        {background-color: #e2d5a4}
    a           {text-decoration: none;
                 font-weight: bold}
    a:link      {background: none;
                 color: black; text-decoration: none}
    a:visited   {background: none;
                 color: black; text-decoration: none}
    a:active    {background: #e2d5a4;
                 color: black; text-decoration: none}
    a:hover     {background: #e2d5a4;
                 color: black; text-decoration: none}
    .page       {
                }
    .header     {background-color: #f2e5c4;
                 border: 4px solid black;
                }
    .title      {background-color: #f2e5c4;
                 border: 1px solid black;
                 text-align: center;
                 font-size: 150%;
                 margin-bottom: 8px;
                }
    .content    {background-color: #faf6d4;
                 border: 2px solid black;
                }
    .footer     {background-color: #f2e5c4;
                 border: 4px solid black;
                }
    .tmenu      {background-color: #faf6d4;
                 border: 1px solid black;
                 padding: 1px; spacing: 3px}
      </style>
   </head>
   <body>
    <table class="page" cellpadding="12" cellspacing="12" width="100%">
      <tr valign="middle">
        <td class="header">
           <img src="titulo.png">
        </td>
      </tr>
      <tr>
        <td class="content">
