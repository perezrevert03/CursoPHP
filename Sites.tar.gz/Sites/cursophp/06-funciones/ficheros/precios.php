<?php
$productos= array("frenos" => array("desc"=>"Frenos",
                                    "precio"=>100),
                  "aceite" => array("desc"=>"Latas de aceite",
                                    "precio"=>10),
                  "ruedas" => array("desc"=>"Neum�ticos",
                                    "precio"=>4),
                  "bujias" => array("desc"=>"Buj�as",
                                    "precio"=>2)
                 );
?>
