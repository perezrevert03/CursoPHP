<?php
// Cualquier manipulaci�n de las cookies se debe hacer antes de imprimir
// ninguna l�nea

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>P�gina de visita</title>

</head>
<body>

<?php
// Mostrar la informaci�n del usuario y el contador de visitas

 ?>

</body>
</html>
