<?php
$productos= array("frenos" => array("desc"=>"Frenos de disco",
                                    "precio"=>100),
                  "aceite" => array("desc"=>"Latas de aceite",
                                    "precio"=>10),
                  "ruedas" => array("desc"=>"Neum&aacute;ticos",
                                    "precio"=>4),
                  "bujias" => array("desc"=>"Buj&iacute;as",
                                    "precio"=>2)
                 );
?>
