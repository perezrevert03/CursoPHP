<html>
<head>
<title>Fichero de prueba.php</title>
</head>
<body>
<h1>Fichero de prueba.php</h1>

<!-- Insertar detr�s el c�digo PHP -->

<?php
echo "Hola 1<br>\n";
?>

<?
echo "Hola 2<br>\n";
?>

<script language="php">
echo "Hola 3<br>\n";
</script>

<%
echo "Hola 4<br>\n";
%>

</body>
</html>
