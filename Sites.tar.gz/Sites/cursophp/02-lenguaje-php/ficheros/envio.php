<html>
<head>
<title>Costes del envÃ­o de piezas</title>
</head>
<body>
<h1>Costes de envÃ­o</h1>

<table border="1" cellpadding="2">
<tr bgcolor="#dedede">
  <td>Distancia (km)</td>
  <td>Precio (euros)</td>
</tr>
<!-- Fila de ejemplo -->
<tr bgcolor="#f0f0f0" align="center">
  <td>0 - 10</td>
  <td>5</td>
</tr>
<!-- Fin de la fila de ejemplo -->
</table>

</body>
</html>